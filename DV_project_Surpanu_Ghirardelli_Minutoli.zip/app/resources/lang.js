languageController.$inject = ['$scope'];

function languageController($scope) {
    $scope.lang = {
      openMenu: "Open Menu",
      closeButton: "Close"     
    }
}

let lang = {
  
};