# Evolution of International Migrant Stock

`Authors`: _Daniel Surpanu_, _Federico Minutoli_, and _Matteo Ghirardelli_

The project is available online on GitHub at https://github.com/danigit/world_migration_visualization
